<?php
defined('ABSPATH') || exit;

class CSAP_Settings {
    public function __construct() {
        add_action('admin_menu', array($this, 'add_settings_page'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_scripts'));
    }

    public function add_settings_page() {
        add_options_page(
            'Cyber Social Auto-Poster Settings',
            'Social Auto-Poster',
            'manage_options',
            'cyber-social-auto-poster',
            array($this, 'render_settings_page')
        );
    }

    public function render_settings_page() {
        ?>
        <div class="wrap csap-settings-page">
            <h1>Cyber Social Auto-Poster Settings</h1>
            <form method="post" action="options.php">
                <?php
                settings_fields('cyber-social-auto-poster');
                do_settings_sections('cyber-social-auto-poster');
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }

    public function enqueue_scripts($hook) {
        if ($hook === 'settings_page_cyber-social-auto-poster') {
            wp_enqueue_style('csap-admin-css', CSAP_PLUGIN_URL . 'assets/css/admin-style.css');
            wp_enqueue_script('csap-admin-js', CSAP_PLUGIN_URL . 'assets/js/admin-script.js', array('jquery'), '1.0', true);
        }
    }
}
