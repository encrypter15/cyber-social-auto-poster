<?php
defined('ABSPATH') || exit;

class CSAP_Social_Poster {
    public function __construct() {
        add_action('publish_post', array($this, 'auto_post_to_social'), 10, 2);
    }

    public function auto_post_to_social($post_id, $post) {
        $options = get_option('csap_options', array());
        $title = get_the_title($post_id);
        $link = get_permalink($post_id);
        $message = $title . ' ' . $link . ' ' . $options['default_hashtags'];

        // Placeholder for API calls to social platforms
        error_log("Auto-posting to social: $message");
        // Implement Twitter, Facebook, LinkedIn APIs here
    }
}
